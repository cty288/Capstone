﻿namespace _02._Scripts.Runtime.Common.Properties {
	public interface IDescriptionGetter {
		public string GetDescription(ICustomProperty customProperty);
	}
	
}