﻿namespace _02._Scripts.Runtime.Base.Property {
	public class SerializedChildPropertyInfo {
		public bool IsInBase;
		public bool IsInReal;

		public SerializedChildPropertyInfo(bool isInBase, bool isInReal) {
			IsInBase = isInBase;
			IsInReal = isInReal;
		}
	}
}